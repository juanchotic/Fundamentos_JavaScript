var titulo = document.getElementById("mititulo");
//alert(titulo);
titulo.innerHTML = "Este es un NUEVO titulo";
