var titulo = document.getElementById("mititulo");

titulo.onclick = function(){
	titulo.innerHTML = "Este es un NUEVO titulo";
}
