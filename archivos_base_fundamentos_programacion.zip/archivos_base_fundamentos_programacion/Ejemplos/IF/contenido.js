var a = 5;
var b = 5;

if ( a < b ) {
	alert("No son iguales");
}

if ( a == b ) 
{
	alert("Si que son iguales")
}
