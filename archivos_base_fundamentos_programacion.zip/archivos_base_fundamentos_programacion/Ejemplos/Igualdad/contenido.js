var a = 123;
var b = 123;

// Comprobación de igualdad

if ( a === b ) {
	alert("Si, son iguales");
} else {
	alert("No, NO son iguales");
}
