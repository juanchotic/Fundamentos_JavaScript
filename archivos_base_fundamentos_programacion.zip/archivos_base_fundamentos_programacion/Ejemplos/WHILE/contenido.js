var cantidad = 0;

// Crear el índice

var i = 1;

// Crear la condición

while ( i <= 10 ) {

	cantidad = cantidad + 100;
	// Incrementar el índice
	i++;

}

alert("El valor final es "+cantidad)
