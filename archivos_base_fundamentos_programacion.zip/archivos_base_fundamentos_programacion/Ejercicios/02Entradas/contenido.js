var nombre = prompt("Dime tu nombre");
alert("Hola," + nombre);