var a;
a = 5;
a = 100000;
a = 123.456;
a = -500;
alert(a);
