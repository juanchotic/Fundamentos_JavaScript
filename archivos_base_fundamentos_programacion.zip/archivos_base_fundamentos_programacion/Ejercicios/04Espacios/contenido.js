
var a = 5;
var b = 10;
var c = 20;

a++;
b--;
c += 10;
var x = true;
var z = false;

var nombre = prompt("Dime tu \n nombre");
alert("Hola, " + nombre);
