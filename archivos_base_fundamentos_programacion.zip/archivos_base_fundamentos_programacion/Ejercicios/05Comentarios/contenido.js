// Esto es un comentario
var a = 5;
var b = 10;
var c = 20;

// Esta es la sección de booleanas
a++;
b--;
c += 10;
var x = true;
var z = false;

/*
var nombre = prompt("Dime tu \n nombre");
alert("Hola, " + nombre);
*/

/* 
Esto es un comentario
Pero esto ya no lo es
Esto es un comentario
Pero esto ya no lo es
Esto es un comentario
Pero esto ya no lo es
Esto es un comentario
Pero esto ya no lo es
*/
