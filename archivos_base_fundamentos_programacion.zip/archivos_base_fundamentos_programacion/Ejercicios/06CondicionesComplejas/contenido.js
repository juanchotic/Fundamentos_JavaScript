var balance = 15000;

if( balance >= 0 ) {
	alert("El balance es positivo");
	if (balance > 10000) {
		alert("El balance es muy grande")
	}
} else {
	alert("El balance es negativo");
}
