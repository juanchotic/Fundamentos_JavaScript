var combustible = "Super98";

switch (combustible) {
	case "Diesel":
		alert("1,02E");
		break;
	case "Super97":
		alert("1,45E");
		break;
	case "Super95":
		alert("1,67E");
		break;
	default:
		alert("Lo que has escrito no lo tengo en el catalogo de combustibles")
}

