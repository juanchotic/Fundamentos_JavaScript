function miFuncion() {
	var a = 5;
	var b = 10;
	var c = 20;
	var d = a + b + c;
	alert("El valor de d es igual a : " + d);
}

miFuncion();
miFuncion();
miFuncion();
miFuncion();
miFuncion();


