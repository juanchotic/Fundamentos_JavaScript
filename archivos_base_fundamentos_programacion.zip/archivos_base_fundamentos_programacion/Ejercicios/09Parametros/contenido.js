function suma(a,b){
	var resultado = a + b;
	return resultado;
}

var sumando = suma(12,14);

alert(sumando);

